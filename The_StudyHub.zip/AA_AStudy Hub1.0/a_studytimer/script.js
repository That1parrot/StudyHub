// Global variables
let currentMode = 'Study';  // Initial mode is Study
let studyTime;
let breakTime;
let timerId = null;
let paused = false;  // Timer is not paused by default
let alertSound = new Audio('alert.wav');  // Alert sound
let studyCompleteSound = new Audio('studycomplete.wav');  // Sound for study session completion
let breakCompleteSound = new Audio('breakcomplete.wav');  // Sound for break completion
let chessWindow = null;

// Total Study Time variables
let totalStudyTime = 0; // Total study time in seconds
let studyThreshold = 3600; //The Correct Number
let bonusBreakTime = 600; // 10-minute bonus in seconds (600 seconds)

document.addEventListener("DOMContentLoaded", function() {
    console.log("Document loaded. Initializing timer...");
    setInitialTimes();  // Initialize times when the page loads
    updateTimer();  // Start the timer
});

function updateTimer() {
    clearTimeout(timerId);  // Clear the previous timer

    if (!paused) {  // Only update the timer if it's not paused
        let time = currentMode === 'Study' ? studyTime : breakTime;
        console.log(`[Timer Update] Mode: ${currentMode}, Time Left: ${time}s`);

        if (time > 0) {
            currentMode === 'Study' ? studyTime-- : breakTime--;

            // Update the total study time if in study mode
            if (currentMode === 'Study') {
                totalStudyTime++;  // Increment total study time
                updateTotalStudyTimeDisplay();  // Update the study time display
            }

            if (time <= 10 && time > 0) {
                alertSound.play();  // Play alert sound at 10 seconds remaining
            }
        } else {
            endCurrentSession();  // End the current session when time runs out
        }

        displayTime();  // Update the time display on the UI
    }

    // Continue updating the timer every second regardless of tab state
    timerId = setTimeout(updateTimer, 1000);  // Ensure this runs every second
}












// Detect if the tab is visible or hidden
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        console.log("Tab is not in focus.");
    } else {
        console.log("Tab is back in focus.");
        if (isRunning) {
            updateTimer();  // Ensure the timer continues running if it's active
        }
    }
});







function updateTotalStudyTimeDisplay() {
    let minutes = Math.floor(totalStudyTime / 60);
    let seconds = totalStudyTime % 60;
    document.getElementById('totalStudyTimeLabel').textContent = `Total Study Time: ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function setInitialTimes() {
    // Set default study and break times
    let studyMinutes = 30;  // 30 minutes for study
    let breakMinutes = 5;   // 5 minutes for break

    studyTime = studyMinutes * 60;
    breakTime = breakMinutes * 60;
    console.log(`Default Times set - Study: ${studyMinutes} minutes, Break: ${breakMinutes} minutes`);
    
    displayTime();  // Display the initial time
}


function displayTime() {
    let time = currentMode === 'Study' ? studyTime : breakTime;
    let minutes = Math.floor(time / 60);
    let seconds = time % 60;
    document.getElementById('timerLabel').textContent = `${currentMode} Time: ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    console.log(`[Display Time] ${currentMode} Time: ${minutes}:${seconds}`);
}

function endCurrentSession() {
    if (currentMode === 'Study') {
        studyCompleteSound.play();
        console.log(`[Session End] Study session ended. Switching to break.`);
        currentMode = 'Break';
    } else {
        breakCompleteSound.play();
        console.log(`[Session End] Break session ended.`);
        currentMode = 'Study';  // Switch back to Study mode after break ends
    }

    clearTimeout(timerId);  // Stop the timer until the next session
    displayTime();  // Update the display to show the updated time
}

function resetTimer() {
    clearTimeout(timerId);
    studyTime = 0;
    breakTime = 0;
    totalStudyTime = 0;  // Reset total study time
    updateTotalStudyTimeDisplay();  // Reset the total study time display
    paused = true;
    document.getElementById('pauseButton').textContent = 'Resume';
    console.log("Timer reset.");
    displayTime();
}

function togglePause() {
    console.log('Toggling pause, current state:', paused);  // Log the current state before toggling
    paused = !paused;
    document.getElementById('pauseButton').textContent = paused ? 'Resume' : 'Pause';
    if (!paused) {
        updateTimer();
    }
}











function switchMode() {
    // Switch modes even if the timer is paused
    clearTimeout(timerId);  // Stop the current timer before switching

    // Get the increment values from the input fields (study in minutes, break in seconds)
    let studyIncrement = parseInt(document.getElementById('studyIncrement').value) * 60; // Convert to seconds
    let breakIncrement = parseInt(document.getElementById('breakIncrement').value); // Already in seconds

    // Switch between Study and Break modes
    if (currentMode === 'Study') {
        currentMode = 'Break';
        if (!paused) {
            breakTime += breakIncrement;  // Add the break increment only if not paused
            console.log(`[Switch Mode] Switching to Break. Adding ${breakIncrement} seconds.`);
        } else {
            console.log(`[Switch Mode] Switching to Break (paused). No time added.`);
        }
    } else {
        currentMode = 'Study';
        if (!paused) {
            studyTime += studyIncrement;  // Add the study increment only if not paused
            console.log(`[Switch Mode] Switching to Study. Adding ${studyIncrement / 60} minutes.`);
        } else {
            console.log(`[Switch Mode] Switching to Study (paused). No time added.`);
        }
    }

    displayTime();  // Update the timer display immediately

    if (!paused) {
        updateTimer();  // Restart the timer only if not paused
    }
}




























function closeChessGame() {
    if (chessWindow) {
        chessWindow.close();
        console.log("Chess game closed.");
    }
}

function togglePause() {
    console.log('Toggling pause, current state:', paused);  // Log the current state before toggling
    paused = !paused;
    document.getElementById('pauseButton').textContent = paused ? 'Resume' : 'Pause';
    if (!paused) {
        updateTimer();
    }
}

// function uploadBackground() {
//     const fileInput = document.getElementById('backgroundUploader');
//     if (fileInput.files && fileInput.files[0]) {
//         const reader = new FileReader();
//         reader.onload = function(e) {
//             document.body.style.backgroundImage = `url(${e.target.result})`;
//             document.body.style.backgroundSize = "cover";
//             console.log("Background updated.");
//         };
//         reader.readAsDataURL(fileInput.files[0]);
//     }
// }

function openBackgroundLibrary() {
    const library = document.getElementById('backgroundLibrary');
    library.style.display = library.style.display === 'none' ? 'block' : 'none';
    console.log("Background library toggled.");
}

// JavaScript to toggle gradient controls
function toggleGradientControls() {
    var gradientControls = document.getElementById('backgroundLibrary');
    gradientControls.style.display = (gradientControls.style.display === 'none' || gradientControls.style.display === '') ? 'block' : 'none';
}

function applyGradient() {
    var color1 = document.getElementById('color1').value;
    var color2 = document.getElementById('color2').value;
    document.body.style.background = `linear-gradient(to bottom, ${color1}, ${color2})`;
}


// function setPresetBackground() { 
//     document.body.style.backgroundImage = 'url("MuslimMoon.png")';
//     document.body.style.backgroundSize = "cover";
//     console.log("Preset background set.");
// }
