// Pomodoro Timer logic
let workTime = 25 * 60;  // 25 minutes in seconds
let breakTime = 5 * 60;   // 5 minutes in seconds
let timeLeft = workTime;  // Time left to display
let isWorkTime = true;    // Flag to track work/break time
let isRunning = false;    // Flag to track if the timer is running
let isPaused = false;     // Flag to track if the timer is paused
let timerId = null;       // To store the setInterval ID
let startTime;            // To store the start time of the timer

// DOM elements
const timerElement = document.getElementById('timer');
const progressCircle = document.querySelector('circle.progress');
const startPauseBtn = document.getElementById('startPauseBtn');
const resetBtn = document.getElementById('resetBtn');
const workInput = document.getElementById('workTime');
const breakInput = document.getElementById('breakTime');
let alertSound = new Audio('alert.wav');  // Alert sound

// Disable reset initially
resetBtn.disabled = true;

// Start or Pause the timer
function toggleStartPause() {
    if (!isRunning) {
        startTimer();  // If the timer isn't running, start it
    } else {
        pauseTimer();  // If the timer is running, pause it
    }
}

// Start the timer
function startTimer() {
    isRunning = true;
    isPaused = false;
    resetBtn.disabled = false;  // Enable reset button

    // If the timer was paused, resume from where it left off
    if (!startTime || isPaused) {
        startTime = Date.now() - (workTime - timeLeft) * 1000;  // Resume from where we paused
    } else {
        startTime = Date.now();
        timeLeft = isWorkTime ? workTime : breakTime;  // Reset time to work/break time
    }

    startPauseBtn.textContent = "Pause";  // Change to 'Pause'
    startPauseBtn.style.backgroundColor = "#969900";  // Change button color to yellow

    const endTime = startTime + timeLeft * 1000; // Calculate the end time in milliseconds

    timerId = setInterval(() => {
        let now = Date.now();
        timeLeft = Math.max(0, Math.floor((endTime - now) / 1000));  // Calculate remaining time in seconds
        updateDisplay(timeLeft);  // Update the timer display
        updateProgress();  // Update progress circle

        if (timeLeft <= 10 && timeLeft > 0) {
            alertSound.play();  // Play alert sound during the last 10 seconds
        }

        if (timeLeft <= 0) {
            clearInterval(timerId);  // Clear the timer interval
            isWorkTime = !isWorkTime;  // Toggle between work and break time
            isRunning = false;
            startPauseBtn.textContent = "Start";  // Change button back to 'Start'
            startPauseBtn.style.backgroundColor = "";  // Reset button color
            resetProgress();  // Reset progress bar
        }
    }, 1000);  // Update every second
}

// Pause the timer
function pauseTimer() {
    clearInterval(timerId);  // Stop the timer
    isPaused = true;  // Set the paused flag
    isRunning = false;  // Mark the timer as no longer running
    startPauseBtn.textContent = "Start";  // Change back to 'Start'
    startPauseBtn.style.backgroundColor = "";  // Reset button color
}

// Reset the timer
function resetTimer() {
    clearInterval(timerId);  // Stop the timer
    isRunning = false;  // Set timer state to not running
    isPaused = false;  // Reset paused state
    isWorkTime = true;  // Reset to work mode
    timeLeft = workTime;  // Reset time to workTime
    updateDisplay(timeLeft);  // Update the display
    resetProgress();  // Reset circular progress
    startPauseBtn.textContent = "Start";  // Change back to 'Start'
    startPauseBtn.style.backgroundColor = "";  // Reset button color
    resetBtn.disabled = true;  // Disable reset button
}

// Update the timer display
function updateDisplay(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Update the circular progress
function updateProgress() {
    const totalTime = isWorkTime ? workTime : breakTime;
    const progress = (timeLeft / totalTime) * 565;  // 565 is the circumference of the circle
    progressCircle.style.strokeDashoffset = progress;
}

// Reset the circular progress
function resetProgress() {
    progressCircle.style.strokeDashoffset = 565;  // Reset to full circle
}

// Adjust work and break times based on user input
workInput.addEventListener('change', () => {
    workTime = workInput.value * 60;  // Convert minutes to seconds
    resetTimer();  // Reset the timer when time is changed
});

breakInput.addEventListener('change', () => {
    breakTime = breakInput.value * 60;  // Convert minutes to seconds
    resetTimer();  // Reset the timer when time is changed
});

// Event listeners
startPauseBtn.addEventListener('click', toggleStartPause);
resetBtn.addEventListener('click', resetTimer);

// Initialize timer display
timerElement.textContent = `${Math.floor(workTime / 60).toString().padStart(2, '0')}:00`;  // Initialize with default 25 minutes

















// Apply gradient to background
function applyGradient() {
    const color1 = document.getElementById('color1').value;
    const color2 = document.getElementById('color2').value;
    document.body.style.background = `linear-gradient(to bottom, ${color1}, ${color2})`;
}



// Format time for display (MM:SS)
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const secondsRemaining = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${secondsRemaining.toString().padStart(2, '0')}`;
}

// Toggle between work and break mode
function toggleBreak() {
    onBreak = !onBreak;
    if (onBreak) {
        timeLeft = breakTime;
        bar.set(0); // Reset the progress bar for break time
        bar.animate(1, { duration: breakTime * 1000 });
        startTimer(); // Automatically start the break
    } else {
        timeLeft = workTime;
        bar.set(0); // Reset the progress bar for work time
        bar.animate(1, { duration: workTime * 1000 });
        startTimer(); // Automatically start the work session
    }
}

// Adjust work and break times
workInput.addEventListener('change', () => {
    workTime = workInput.value * 60; // Convert minutes to seconds
    resetTimer();
});

breakInput.addEventListener('change', () => {
    breakTime = breakInput.value * 60; // Convert minutes to seconds
    resetTimer();
});

startBtn.addEventListener('click', startTimer);
resetBtn.addEventListener('click', resetTimer);

// Initialize timer display
timerElement.textContent = formatTime(1500); // Default 25 minutes






//BACKGROUND



// Toggle background customization panel
function toggleGradientControls() {
    var gradientControls = document.getElementById('backgroundLibrary');
    gradientControls.style.display = (gradientControls.style.display === 'none' || gradientControls.style.display === '') ? 'block' : 'none';
}

// Apply gradient background
function applyGradient() {
    var color1 = document.getElementById('color1').value;
    var color2 = document.getElementById('color2').value;
    document.body.style.background = `linear-gradient(to bottom, ${color1}, ${color2})`;
}

document.getElementById('startBtn').addEventListener('click', function() {
    // If there's already a running timer, clear it
    if (timerId !== null) {
        clearInterval(timerId);
    }
    startTimer();  // Start the timer
    this.disabled = true;  // Disable the Start button after it's clicked
});

document.getElementById('resetBtn').addEventListener('click', function() {
    if (timerId !== null) {
        clearInterval(timerId);  // Clear the running timer
        timerId = null;  // Reset the timerId
    }
    resetTimer();  // Reset the timer display and values
    document.getElementById('startBtn').disabled = false;  // Re-enable the Start button after reset
});